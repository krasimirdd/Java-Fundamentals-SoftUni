package ex5;

public class Constants {
    private static final int NotStatedNumeric = -1;
    private static final String NotStatedString = "n/a";

    public static int getNotStatedNumeric() {
        return NotStatedNumeric;
    }

    public static String getNotStatedString() {
        return NotStatedString;
    }
}
