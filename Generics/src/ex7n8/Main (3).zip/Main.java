package ex7n8;

import ex7n8.customlist.Engine;

public class Main {
    private static final Engine ENGINE = new Engine();

    public static void main(String[] args) {
        ENGINE.run();
    }
}